<?php
echo elgg_view('izap-videos/view/video/elements/video', array_merge($vars, array('width' => 450)));
?>